// Stub for Arduino header file - For added compatibility with existing arduino libraries
// Include Energia instead
#include "Energia.h"

