1. Instal Energia
2. Copy the Folder Mispigy to the File location energia\hardware\energia\msp430\variants
3. Copy the File Mispigy.ccxml to the File location energia\hardware\tools\DSLite
4. Copy the File boards.txt to the File location energia\hardware\energia\msp430
5. Copy the File MSP430F5528.xml to the File locationenergia\hardware\tools\DSLite\common\targetdb\devices
6. Run the file DPInsta64.exe in the folder Driver